# Release 23.3.0

  * Added tax rebate and tax slabs as a data.frame
  * Fixed few issues in the calculation mechanism. 


# Release 23.2.0

  * First release
