# EasyCalculator <img src="man/figures/logo.png" align="right" height="139" />

Easy financial calculators for India. 

  * Tax calculator: `tax_payable()`
  

## Overview

## Installation

```r
devtools::install_github("Poduval/EasyCalculator/EasyCalculators")
```
## Usage

### Tax calculator

  * Simple calculation of annual tax 
  * Keep possibilities to make bulk appraisals
  * Summarized function to show useful insights
  * Plot functions to show useful insights
  * Calculate tax for any financial year - from 2022 onwards
  
## References 

