# EasyCalculator 0.1.0

This is the initial release.
  
