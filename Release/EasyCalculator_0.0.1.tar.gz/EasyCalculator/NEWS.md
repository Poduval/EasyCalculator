# EasyCalculator 0.0.1

This is the initial release.

## Backlog 
* Add GST calculator: `gst_calculator()`
* Add Loan scheduler: `loan_schedular()`
* Add print, summary, and plot methods for the class `taxcalculator`.
* Add a cheat sheet.
* Add a vignette with examples.
* Add a vignette with concepts implemented in the package.
* Add an embedded shiny app with a single appraisal.
* Add links to the reference documents. 